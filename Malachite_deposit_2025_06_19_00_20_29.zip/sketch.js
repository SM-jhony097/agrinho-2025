let player1; // Objeto para o Jogador 1
let player2; // Objeto para o Jogador 2

function setup() {
  createCanvas(800, 400); // Cria uma tela de 800x400 pixels
  // Inicializa os jogadores
  player1 = new Stickman(150, height - 100, color(255, 0, 0)); // Vermelho
  player2 = new Stickman(width - 150, height - 100, color(255, 0, 0)); // Vermelho
}

function draw() {
  background(220); // Cor de fundo cinza claro
  
  // Desenha os jogadores
  player1.display();
  player2.display();

  // Atualiza a lógica do jogo (movimento, ataques, etc.)
  player1.update();
  player2.update();

  // Verifica colisões e ataques (vamos adicionar isso depois)
  
  // Exemplo de como mover os jogadores com as teclas (vamos refinar isso)
  if (keyIsDown(65)) { // Tecla 'A' para mover o Jogador 1 para a esquerda
    player1.move(-5);
  }
  if (keyIsDown(68)) { // Tecla 'D' para mover o Jogador 1 para a direita
    player1.move(5);
  }
  if (keyIsDown(LEFT_ARROW)) { // Seta esquerda para mover o Jogador 2 para a esquerda
    player2.move(-5);
  }
  if (keyIsDown(RIGHT_ARROW)) { // Seta direita para mover o Jogador 2 para a direita
    player2.move(5);
  }
}

// Classe para criar um boneco de palito (Stickman)
class Stickman {
  constructor(x, y, c) {
    this.x = x;
    this.y = y;
    this.color = c;
    this.bodyHeight = 60;
    this.legLength = 40;
    this.armLength = 30;
    this.headRadius = 15;
    this.speed = 0; // Velocidade de movimento
    this.isAttacking = false; // Estado de ataque
  }

  display() {
    push(); // Salva as configurações de desenho atuais
    translate(this.x, this.y); // Move a origem para a posição do boneco

    stroke(this.color); // Cor do traço
    strokeWeight(3); // Espessura do traço

    // Cabeça
    fill(this.color);
    ellipse(0, -this.bodyHeight - this.headRadius, this.headRadius * 2);

    // Corpo
    line(0, -this.bodyHeight, 0, 0);

    // Braços
    line(0, -this.bodyHeight * 0.7, -this.armLength, -this.bodyHeight * 0.5); // Esquerdo
    line(0, -this.bodyHeight * 0.7, this.armLength, -this.bodyHeight * 0.5);  // Direito

    // Pernas
    line(0, 0, -this.headRadius, this.legLength); // Esquerda
    line(0, 0, this.headRadius, this.legLength);  // Direita
    
    pop(); // Restaura as configurações de desenho
  }

  update() {
    // Atualiza a posição com base na velocidade
    this.x += this.speed;

    // Limita o movimento para dentro da tela
    this.x = constrain(this.x, 0 + this.headRadius, width - this.headRadius);

    // Reinicia a velocidade para zero após cada frame para evitar movimento contínuo sem pressionar a tecla
    this.speed = 0;
  }

  move(amount) {
    this.speed = amount;
  }

  attack() {
    // Lógica para o ataque. Pode ser um simples "soco" ou "chute".
    // Por enquanto, vamos apenas mudar o estado para attacking.
    this.isAttacking = true;
    setTimeout(() => {
      this.isAttacking = false; // O ataque dura um curto período
    }, 200); // 200 milissegundos de ataque
  }
}

// Para o Jogador 1: 'W' para pular, 'A' para esquerda, 'D' para direita, 'S' para ataque
// Para o Jogador 2: 'UP_ARROW' para pular, 'LEFT_ARROW' para esquerda, 'RIGHT_ARROW' para direita, 'DOWN_ARROW' para ataque
function keyPressed() {
  if (key === 's' || key === 'S') {
    player1.attack();
  }
  if (keyCode === DOWN_ARROW) {
    player2.attack();
  }
  // Mais tarde você pode adicionar lógica de pulo aqui
}
